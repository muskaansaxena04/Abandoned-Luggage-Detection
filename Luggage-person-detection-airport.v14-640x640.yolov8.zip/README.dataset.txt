# Luggage-person-detection-airport > 640x640
https://universe.roboflow.com/cars-0jbgu/luggage-person-detection-airport

Provided by a Roboflow user
License: CC BY 4.0

